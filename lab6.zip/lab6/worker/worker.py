def count_words(text):
    text = text.split()
    return len(text)